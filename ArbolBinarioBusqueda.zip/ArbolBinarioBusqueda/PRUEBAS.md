# Pruebas del proyecto ArbolBinarioBusqueda

## 1. Pruebas automáticas (lógica del árbol y validaciones)

Ejecutar en NetBeans: clic derecho sobre `src/pruebas/PruebasArbolBST.java` → *Run File*
(Shift+F6). Resultado obtenido: **100 comprobaciones correctas, 0 fallidas**
(salida completa en `resultados_pruebas.txt`).

| # | Caso exigido | Qué se comprueba |
|---|--------------|------------------|
| 1 | Crear árbol vacío | vacío, tamaño 0, buscar/eliminar/recorridos/amplitud/profundidad/balancear/destruir sin errores |
| 2 | Insertar varios | estructura correcta (raíz 50, hijos 30 y 70, etc.) |
| 3 | Id duplicado | lanza `IllegalArgumentException`, no cambia el árbol |
| 4 | Buscar | existente → empleado; inexistente → `null` |
| 5 | Eliminar hoja | nodo 20 |
| 6 | Eliminar con un hijo | nodo 60 (hijo 65) |
| 7 | Eliminar con dos hijos | nodo 70 y la raíz 50 (sucesor inorden) |
| 8 | Recorridos | inorden, preorden y postorden con el orden esperado |
| 9 | Amplitud y profundidad | 4 y 4 en el ejemplo; casos de 1 nodo y degenerado |
| 10 | Balancear | 15 nodos en lista (prof. 15) → prof. 4; mismos empleados y mismo orden |
| 11 | Destruir | queda vacío y se puede reutilizar |
| 12 | Entradas inválidas en `ArbolBST` | null, id null, textos vacíos, salario null/negativo/NaN/infinito |
| 13 | Validaciones de la GUI | ID con letras/decimal/vacío/desbordado; salario con letras, negativo, NaN, 1e5, "1,500" |

## 2. Pruebas manuales de la interfaz (GUI_ArbolBinarioBusqueda)

Ejecutar el proyecto (F6). Resultado esperado de cada paso:

1. Pulsar **Agregar Empleado** sin crear el árbol → aviso "Primero debe crear el árbol".
2. **Crear Arbol** → "El árbol está listo para utilizarse"; el panel inferior dice "El árbol está vacío".
3. **Buscar / Eliminar / Mostrar Recorridos / Calcular / Balancear / Destruir** con árbol vacío → mensajes claros, sin errores.
4. **Agregar** con ID vacío, `abc`, `3.5`; nombre/puesto/departamento vacíos; salario `abc`, `-5`, `NaN`, `1e5` → mensaje de error comprensible, no se agrega nada.
5. Agregar empleados con ID 50, 30, 70, 20, 40, 60, 80, 65 → el dibujo se actualiza y el último queda resaltado.
6. Agregar otra vez el ID 40 → "Ya existe un empleado con el ID 40".
7. **Buscar** ID 65 (se muestran todos los datos y se resalta en el dibujo) e ID 999 ("NO ENCONTRADO").
8. **Eliminar** 20 (hoja), 60 (un hijo), 70 (dos hijos) → mensaje y dibujo actualizado; eliminar 999 → "NO ENCONTRADO".
9. **Mostrar Recorridos** → elegir Inorden (ids ascendentes), Preorden, Postorden o Los tres.
10. **Calcular Ampli y Prof** → amplitud (máximo de nodos en un nivel) y profundidad (en niveles).
11. Agregar ids 1 a 10 en orden (árbol en forma de lista) → **Balancear Arbol** muestra profundidad antes/después, confirma que se conservan los empleados y muestra la estructura.
12. **Destruir Arbol** → confirmación; luego "El árbol quedó vacío"; se puede volver a agregar empleados.
