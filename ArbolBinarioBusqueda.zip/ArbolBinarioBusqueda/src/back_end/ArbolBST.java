/*
Gonzalez nuñez Isai
Zuñiga de leon Bryan
 */
package back_end;

import Nodos.Empleado;
import Nodos.NodoBST;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;


public class ArbolBST {

    private NodoBST raiz;
    private int tamanio;

    public ArbolBST() {
        this.raiz = null;
        this.tamanio = 0;
    }

    public NodoBST getRaiz() {
        return raiz;
    }

    
    public int getTamanio() {
        return tamanio;
    }

    public boolean estaVacio() {
        return raiz == null;
    }

   
    public void insertar(Empleado empleado) {
        validarEmpleado(empleado);
        Integer id = empleado.getId();

        if (raiz == null) {
            raiz = new NodoBST(empleado);
            tamanio++;
            return;
        }
        NodoBST actual = raiz;
        while (true) {
            int cmp = id.compareTo(actual.getDato().getId());
            if (cmp == 0) {
                throw new IllegalArgumentException("Ya existe un empleado con el ID " + id + ".");
            }
            if (cmp < 0) {
                if (actual.getIzquierdo() == null) {
                    actual.setIzquierdo(new NodoBST(empleado));
                    break;
                }
                actual = actual.getIzquierdo();
            } else {
                if (actual.getDerecho() == null) {
                    actual.setDerecho(new NodoBST(empleado));
                    break;
                }
                actual = actual.getDerecho();
            }
        }
        tamanio++;
    }

    
    private void validarEmpleado(Empleado e) {
        if (e == null) {
            throw new IllegalArgumentException("El empleado no puede ser nulo.");
        }
        if (e.getId() == null) {
            throw new IllegalArgumentException("El ID del empleado es obligatorio.");
        }
        Validaciones.textoRequerido("Nombre", e.getNombre());
        Validaciones.textoRequerido("Puesto", e.getPuesto());
        Validaciones.textoRequerido("Departamento", e.getDepartamento());
        Validaciones.validarSalario(e.getSalario());
    }

   
    public Empleado buscar(Integer id) {
        if (id == null) {
            throw new IllegalArgumentException("El ID a buscar no puede ser nulo.");
        }
        NodoBST actual = raiz;
        while (actual != null) {
            int cmp = id.compareTo(actual.getDato().getId());
            if (cmp == 0) {
                return actual.getDato();
            }
            actual = (cmp < 0) ? actual.getIzquierdo() : actual.getDerecho();
        }
        return null;
    }

   
    public Empleado eliminar(Integer id) {
        if (id == null) {
            throw new IllegalArgumentException("El ID a eliminar no puede ser nulo.");
        }
        Empleado[] eliminado = new Empleado[1];
        raiz = eliminar(raiz, id, eliminado);
        if (eliminado[0] != null) {
            tamanio--;
        }
        return eliminado[0];
    }

    private NodoBST eliminar(NodoBST nodo, Integer id, Empleado[] eliminado) {
        if (nodo == null) {
            return null; 
        }
        int cmp = id.compareTo(nodo.getDato().getId());
        if (cmp < 0) {
            nodo.setIzquierdo(eliminar(nodo.getIzquierdo(), id, eliminado));
            return nodo;
        }
        if (cmp > 0) {
            nodo.setDerecho(eliminar(nodo.getDerecho(), id, eliminado));
            return nodo;
        }
        
        eliminado[0] = nodo.getDato();
        if (nodo.getIzquierdo() == null) {     
            return nodo.getDerecho();
        }
        if (nodo.getDerecho() == null) {        
            return nodo.getIzquierdo();
        }
        
        NodoBST sucesor = nodo.getDerecho();
        while (sucesor.getIzquierdo() != null) {
            sucesor = sucesor.getIzquierdo();
        }
        nodo.setDato(sucesor.getDato());
        Empleado[] descarte = new Empleado[1];
        nodo.setDerecho(eliminar(nodo.getDerecho(), sucesor.getDato().getId(), descarte));
        return nodo;
    }

   
    public List<Empleado> mostrarInOrden() {
        List<Empleado> lista = new ArrayList<>();
        inOrden(raiz, lista);
        return lista;
    }

    private void inOrden(NodoBST n, List<Empleado> lista) {
        if (n == null) {
            return;
        }
        inOrden(n.getIzquierdo(), lista);
        lista.add(n.getDato());
        inOrden(n.getDerecho(), lista);
    }

    
    public List<Empleado> mostrarPreOrden() {
        List<Empleado> lista = new ArrayList<>();
        preOrden(raiz, lista);
        return lista;
    }

    private void preOrden(NodoBST n, List<Empleado> lista) {
        if (n == null) {
            return;
        }
        lista.add(n.getDato());
        preOrden(n.getIzquierdo(), lista);
        preOrden(n.getDerecho(), lista);
    }

    
    public List<Empleado> mostrarPostOrden() {
        List<Empleado> lista = new ArrayList<>();
        postOrden(raiz, lista);
        return lista;
    }

    private void postOrden(NodoBST n, List<Empleado> lista) {
        if (n == null) {
            return;
        }
        postOrden(n.getIzquierdo(), lista);
        postOrden(n.getDerecho(), lista);
        lista.add(n.getDato());
    }

   
    
    public int amplitud() {
        if (raiz == null) {
            return 0;
        }
        int maximo = 0;
        Queue<NodoBST> cola = new ArrayDeque<>();
        cola.add(raiz);
        while (!cola.isEmpty()) {
            int enNivel = cola.size();
            maximo = Math.max(maximo, enNivel);
            for (int i = 0; i < enNivel; i++) {
                NodoBST n = cola.poll();
                if (n.getIzquierdo() != null) {
                    cola.add(n.getIzquierdo());
                }
                if (n.getDerecho() != null) {
                    cola.add(n.getDerecho());
                }
            }
        }
        return maximo;
    }

   
    public int profundidad() {
        return profundidad(raiz);
    }

    private int profundidad(NodoBST n) {
        if (n == null) {
            return 0;
        }
        return 1 + Math.max(profundidad(n.getIzquierdo()), profundidad(n.getDerecho()));
    }

 
     
    public void balancear() {
        if (raiz == null) {
            return;
        }
        List<Empleado> ordenados = mostrarInOrden();
        raiz = construirBalanceado(ordenados, 0, ordenados.size() - 1);
     
    }

    private NodoBST construirBalanceado(List<Empleado> lista, int inicio, int fin) {
        if (inicio > fin) {
            return null;
        }
        int medio = (inicio + fin) / 2;
        NodoBST nodo = new NodoBST(lista.get(medio));
        nodo.setIzquierdo(construirBalanceado(lista, inicio, medio - 1));
        nodo.setDerecho(construirBalanceado(lista, medio + 1, fin));
        return nodo;
    }

    
    public void destruirArbol() {
        raiz = null;
        tamanio = 0;
    }
}
