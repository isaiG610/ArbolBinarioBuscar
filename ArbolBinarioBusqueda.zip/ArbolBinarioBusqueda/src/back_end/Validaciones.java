/*
Gonzalez nuñez Isai
Zuñiga de Leon Bryan
 */
package back_end;


public final class Validaciones {

    private Validaciones() {
    }

    
    public static String textoRequerido(String campo, String valor) {
        if (valor == null || valor.trim().isEmpty()) {
            throw new IllegalArgumentException("El campo " + campo + " es obligatorio y no puede estar vacío.");
        }
        return valor.trim();
    }

    
    public static Integer parseId(String texto) {
        String t = textoRequerido("ID", texto);
        try {
            return Integer.valueOf(t);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(
                    "El ID debe ser un número entero válido (sin letras, decimales ni espacios). Valor recibido: \"" + t + "\".");
        }
    }

    
    public static Double parseSalario(String texto) {
        String t = textoRequerido("Salario", texto);
         
        if (!t.matches("[-+]?(\\d+\\.?\\d*|\\.\\d+)")) {
            throw new IllegalArgumentException(
                    "El salario debe ser un número válido (ejemplo: 12500.50). Valor recibido: \"" + t + "\".");
        }
        double valor = Double.parseDouble(t);
        validarSalario(valor);
        return valor;
    }

    
    public static void validarSalario(Double salario) {
        if (salario == null) {
            throw new IllegalArgumentException("El salario es obligatorio.");
        }
        if (salario.isNaN() || salario.isInfinite()) {
            throw new IllegalArgumentException("El salario debe ser un número finito.");
        }
        if (salario < 0) {
            throw new IllegalArgumentException("El salario no puede ser negativo.");
        }
    }
}
