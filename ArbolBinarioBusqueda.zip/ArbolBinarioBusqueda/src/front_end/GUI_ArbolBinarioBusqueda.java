/*
Gonzalez Nuñez Isai
Zuñiga de leon Bryan
 */
package front_end;

import Nodos.Empleado;
import Nodos.NodoBST;
import back_end.ArbolBST;
import back_end.Validaciones;
import java.util.List;
import java.util.Locale;
import javax.swing.JOptionPane;


public class GUI_ArbolBinarioBusqueda extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GUI_ArbolBinarioBusqueda.class.getName());

    
    private ArbolBST arbol;
    
    private PanelArbol panelArbol;

   
    public GUI_ArbolBinarioBusqueda() {
        initComponents();
        panelArbol = (PanelArbol) jPanel2;
        setTitle("Árbol Binario de Búsqueda - Gestión de Empleados");
        setLocationRelativeTo(null);
        mostrar("Bienvenido", "Presione \"Crear Arbol\" para comenzar.");
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelTitulo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        PanelCamposEntrada = new javax.swing.JPanel();
        lbl_ID = new javax.swing.JLabel();
        lbl_Nombre = new javax.swing.JLabel();
        lbl_Puesto = new javax.swing.JLabel();
        lbl_Departamento = new javax.swing.JLabel();
        lbl_Salario = new javax.swing.JLabel();
        txt_Departamento = new javax.swing.JTextField();
        txt_ID = new javax.swing.JTextField();
        txt_Nombre = new javax.swing.JTextField();
        txt_Puesto = new javax.swing.JTextField();
        txt_Salario = new javax.swing.JTextField();
        PanelResultados = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txa_Resultados = new javax.swing.JTextArea();
        PanelBotones = new javax.swing.JPanel();
        btn_Crear = new javax.swing.JButton();
        btn_buscar = new javax.swing.JButton();
        btn_Mostrar = new javax.swing.JButton();
        btn_Balancear = new javax.swing.JButton();
        btn_Agregar = new javax.swing.JButton();
        btn_Eliminar = new javax.swing.JButton();
        btn_Calcular = new javax.swing.JButton();
        btn_Destruir = new javax.swing.JButton();
        PanelVisualizarArbol = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel2 = new PanelArbol();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabel1.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        jLabel1.setText("Árbol Binario de Búsqueda (BST) — Gestión de Empleados");

        javax.swing.GroupLayout PanelTituloLayout = new javax.swing.GroupLayout(PanelTitulo);
        PanelTitulo.setLayout(PanelTituloLayout);
        PanelTituloLayout.setHorizontalGroup(
            PanelTituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelTituloLayout.createSequentialGroup()
                .addGap(204, 204, 204)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelTituloLayout.setVerticalGroup(
            PanelTituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelTituloLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jLabel1)
                .addContainerGap(43, Short.MAX_VALUE))
        );

        PanelCamposEntrada.setBorder(javax.swing.BorderFactory.createTitledBorder("Formulario"));

        lbl_ID.setText("ID:");

        lbl_Nombre.setText("Nombre:");

        lbl_Puesto.setText("Puesto:");

        lbl_Departamento.setText("Departamento:");

        lbl_Salario.setText("Salario:");

        txt_Departamento.addActionListener(this::txt_DepartamentoActionPerformed);

        txt_ID.addActionListener(this::txt_IDActionPerformed);

        txt_Nombre.addActionListener(this::txt_NombreActionPerformed);

        txt_Puesto.addActionListener(this::txt_PuestoActionPerformed);

        txt_Salario.addActionListener(this::txt_SalarioActionPerformed);

        javax.swing.GroupLayout PanelCamposEntradaLayout = new javax.swing.GroupLayout(PanelCamposEntrada);
        PanelCamposEntrada.setLayout(PanelCamposEntradaLayout);
        PanelCamposEntradaLayout.setHorizontalGroup(
            PanelCamposEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelCamposEntradaLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(PanelCamposEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_Departamento)
                    .addComponent(lbl_ID)
                    .addComponent(lbl_Nombre)
                    .addComponent(lbl_Puesto)
                    .addComponent(lbl_Salario))
                .addGap(18, 18, 18)
                .addGroup(PanelCamposEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txt_Salario, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE)
                    .addComponent(txt_Departamento)
                    .addComponent(txt_Puesto)
                    .addComponent(txt_Nombre)
                    .addComponent(txt_ID))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        PanelCamposEntradaLayout.setVerticalGroup(
            PanelCamposEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelCamposEntradaLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(PanelCamposEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_ID)
                    .addComponent(txt_ID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(PanelCamposEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_Nombre)
                    .addComponent(txt_Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(PanelCamposEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_Puesto)
                    .addComponent(txt_Puesto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(PanelCamposEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_Departamento)
                    .addComponent(txt_Departamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(PanelCamposEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_Salario)
                    .addComponent(txt_Salario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PanelResultados.setBorder(javax.swing.BorderFactory.createTitledBorder("Resultados"));

        jScrollPane1.setPreferredSize(new java.awt.Dimension(486, 261));

        txa_Resultados.setEditable(false);
        txa_Resultados.setColumns(20);
        txa_Resultados.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        txa_Resultados.setRows(5);
        jScrollPane1.setViewportView(txa_Resultados);

        javax.swing.GroupLayout PanelResultadosLayout = new javax.swing.GroupLayout(PanelResultados);
        PanelResultados.setLayout(PanelResultadosLayout);
        PanelResultadosLayout.setHorizontalGroup(
            PanelResultadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        PanelResultadosLayout.setVerticalGroup(
            PanelResultadosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelResultadosLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        PanelBotones.setBorder(javax.swing.BorderFactory.createTitledBorder("Opciones"));

        btn_Crear.setText("Crear Arbol");
        btn_Crear.addActionListener(this::btn_CrearActionPerformed);

        btn_buscar.setText("Buscar Empleado");
        btn_buscar.addActionListener(this::btn_buscarActionPerformed);

        btn_Mostrar.setText("Mostrar Recorridos");
        btn_Mostrar.addActionListener(this::btn_MostrarActionPerformed);

        btn_Balancear.setText("Balancear Arbol");
        btn_Balancear.addActionListener(this::btn_BalancearActionPerformed);

        btn_Agregar.setText("Agregar Empleado");
        btn_Agregar.addActionListener(this::btn_AgregarActionPerformed);

        btn_Eliminar.setText("Eliminar Empleado");
        btn_Eliminar.addActionListener(this::btn_EliminarActionPerformed);

        btn_Calcular.setText("Calcular Ampli y Prof");
        btn_Calcular.addActionListener(this::btn_CalcularActionPerformed);

        btn_Destruir.setText("Destruir Arbol");
        btn_Destruir.addActionListener(this::btn_DestruirActionPerformed);

        javax.swing.GroupLayout PanelBotonesLayout = new javax.swing.GroupLayout(PanelBotones);
        PanelBotones.setLayout(PanelBotonesLayout);
        PanelBotonesLayout.setHorizontalGroup(
            PanelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelBotonesLayout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addGroup(PanelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_Mostrar, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn_Balancear, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_buscar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_Crear, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(PanelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_Eliminar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_Agregar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_Calcular, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn_Destruir, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18))
        );
        PanelBotonesLayout.setVerticalGroup(
            PanelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelBotonesLayout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addGroup(PanelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Crear)
                    .addComponent(btn_Agregar))
                .addGap(35, 35, 35)
                .addGroup(PanelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_buscar)
                    .addComponent(btn_Eliminar))
                .addGap(35, 35, 35)
                .addGroup(PanelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Mostrar)
                    .addComponent(btn_Calcular))
                .addGap(35, 35, 35)
                .addGroup(PanelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Balancear)
                    .addComponent(btn_Destruir))
                .addGap(35, 35, 35))
        );

        PanelVisualizarArbol.setBorder(javax.swing.BorderFactory.createTitledBorder("Arbol Visual"));

        jScrollPane2.setPreferredSize(new java.awt.Dimension(1154, 434));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1154, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 434, Short.MAX_VALUE)
        );

        jScrollPane2.setViewportView(jPanel2);

        javax.swing.GroupLayout PanelVisualizarArbolLayout = new javax.swing.GroupLayout(PanelVisualizarArbol);
        PanelVisualizarArbol.setLayout(PanelVisualizarArbolLayout);
        PanelVisualizarArbolLayout.setHorizontalGroup(
            PanelVisualizarArbolLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelVisualizarArbolLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        PanelVisualizarArbolLayout.setVerticalGroup(
            PanelVisualizarArbolLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelVisualizarArbolLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(PanelCamposEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PanelResultados, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PanelBotones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(PanelTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(PanelVisualizarArbol, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(PanelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(PanelCamposEntrada, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(PanelResultados, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(PanelBotones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(PanelVisualizarArbol, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        PanelTitulo.getAccessibleContext().setAccessibleName("opciones");
        PanelCamposEntrada.getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_CrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_CrearActionPerformed
if (arbol != null && !arbol.estaVacio()) {
            int op = JOptionPane.showConfirmDialog(this,
                    "Ya existe un árbol con " + arbol.getTamanio() + " empleado(s).\n"
                    + "Si crea uno nuevo se perderán esos datos. ¿Desea continuar?",
                    "Crear árbol", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (op != JOptionPane.YES_OPTION) {
                mostrar("Crear árbol", "Operación cancelada. Se conserva el árbol actual.");
                return;
            }
        }
        arbol = new ArbolBST();
        panelArbol.setArbol(arbol);
        limpiarCampos();
        mostrar("Crear árbol", "El árbol está listo para utilizarse.\n"
                + "Capture los datos del empleado y presione \"Agregar Empleado\".");
    }//GEN-LAST:event_btn_CrearActionPerformed

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed
    final String op = "Buscar empleado";
        if (!hayArbol(op)) {
            return;
        }
        try {
            Integer id = Validaciones.parseId(txt_ID.getText());
            Empleado e = arbol.buscar(id);
            if (e == null) {
                panelArbol.setIdResaltado(null);
                mostrar(op, "NO ENCONTRADO: no existe un empleado con el ID " + id + "."
                        + (arbol.estaVacio() ? "\n(El árbol está vacío.)" : ""));
            } else {
                panelArbol.setIdResaltado(id);
                mostrar(op, "Empleado encontrado:\n" + detalle(e));
            }
        } catch (IllegalArgumentException ex) {
            error(op, ex.getMessage());
        }
    }//GEN-LAST:event_btn_buscarActionPerformed

    private void btn_MostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_MostrarActionPerformed
        elegirRecorrido();
    }//GEN-LAST:event_btn_MostrarActionPerformed

    private void btn_BalancearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_BalancearActionPerformed
    final String op = "Balancear árbol";
        if (!hayArbol(op)) {
            return;
        }
        if (arbol.estaVacio()) {
            mostrar(op, "El árbol está vacío; no hay nada que balancear.");
            return;
        }
        int profAntes = arbol.profundidad();
        int ampAntes = arbol.amplitud();
        int totalAntes = arbol.getTamanio();
        List<Empleado> antes = arbol.mostrarInOrden();

        arbol.balancear();
        panelArbol.actualizar();

        int profDespues = arbol.profundidad();
        int ampDespues = arbol.amplitud();
        boolean conservados = arbol.getTamanio() == totalAntes && antes.equals(arbol.mostrarInOrden());

        StringBuilder sb = new StringBuilder();
        sb.append("                 ANTES   DESPUÉS\n");
        sb.append(String.format("Profundidad:     %5d   %7d%n", profAntes, profDespues));
        sb.append(String.format("Amplitud:        %5d   %7d%n", ampAntes, ampDespues));
        sb.append(String.format("Empleados:       %5d   %7d%n", totalAntes, arbol.getTamanio()));
        sb.append("\n").append(conservados
                ? "Todos los empleados se conservaron (mismos IDs y mismo orden inorden)."
                : "ADVERTENCIA: la lista de empleados cambió después de balancear.");
        sb.append("\n\nEstructura resultante (I = hijo izquierdo, D = hijo derecho):\n");
        estructura(arbol.getRaiz(), "", "", sb);
        mostrar(op, sb.toString());
    }//GEN-LAST:event_btn_BalancearActionPerformed

    private void btn_AgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_AgregarActionPerformed
            final String op = "Agregar empleado";
        if (!hayArbol(op)) {
            return;
        }
        try {
            Integer id = Validaciones.parseId(txt_ID.getText());
            String nombre = Validaciones.textoRequerido("Nombre", txt_Nombre.getText());
            String puesto = Validaciones.textoRequerido("Puesto", txt_Puesto.getText());
            String departamento = Validaciones.textoRequerido("Departamento", txt_Departamento.getText());
            Double salario = Validaciones.parseSalario(txt_Salario.getText());

            if (arbol.buscar(id) != null) {
                throw new IllegalArgumentException(
                        "Ya existe un empleado con el ID " + id + ". Use un identificador diferente.");
            }
            Empleado e = new Empleado(id, nombre, puesto, departamento, salario);
            arbol.insertar(e);  

            panelArbol.actualizar();
            panelArbol.setIdResaltado(id);
            limpiarCampos();
            mostrar(op, "Empleado agregado correctamente:\n" + detalle(e)
                    + "\n\nTotal de empleados en el árbol: " + arbol.getTamanio());
        } catch (IllegalArgumentException ex) {
            error(op, ex.getMessage());
        }
    }//GEN-LAST:event_btn_AgregarActionPerformed

    private void btn_EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_EliminarActionPerformed
    final String op = "Eliminar empleado";
        if (!hayArbol(op)) {
            return;
        }
        try {
            Integer id = Validaciones.parseId(txt_ID.getText());
            Empleado e = arbol.eliminar(id);
            if (e == null) {
                mostrar(op, "NO ENCONTRADO: no existe un empleado con el ID " + id + ", no se eliminó nada."
                        + (arbol.estaVacio() ? "\n(El árbol está vacío.)" : ""));
            } else {
                panelArbol.actualizar();
                limpiarCampos();
                mostrar(op, "Empleado eliminado correctamente:\n" + detalle(e)
                        + "\n\nEmpleados restantes: " + arbol.getTamanio());
            }
        } catch (IllegalArgumentException ex) {
            error(op, ex.getMessage());
        }
    }//GEN-LAST:event_btn_EliminarActionPerformed

    private void btn_CalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_CalcularActionPerformed
        elegirCalculo();
    }//GEN-LAST:event_btn_CalcularActionPerformed

    private void btn_DestruirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_DestruirActionPerformed
    final String op = "Destruir árbol";
        if (!hayArbol(op)) {
            return;
        }
        if (!arbol.estaVacio()) {
            int r = JOptionPane.showConfirmDialog(this,
                    "Se eliminarán los " + arbol.getTamanio() + " empleado(s) del árbol. ¿Desea continuar?",
                    op, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (r != JOptionPane.YES_OPTION) {
                mostrar(op, "Operación cancelada. El árbol no se modificó.");
                return;
            }
        }
        arbol.destruirArbol();
        panelArbol.actualizar();
        limpiarCampos();
        mostrar(op, "El árbol quedó vacío (0 empleados) y está listo para utilizarse nuevamente.");
    }//GEN-LAST:event_btn_DestruirActionPerformed

    private void txt_IDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_IDActionPerformed
        txt_Nombre.requestFocusInWindow();
    }//GEN-LAST:event_txt_IDActionPerformed

    private void txt_NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_NombreActionPerformed
        txt_Puesto.requestFocusInWindow();
    }//GEN-LAST:event_txt_NombreActionPerformed

    private void txt_PuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_PuestoActionPerformed
        txt_Departamento.requestFocusInWindow();
    }//GEN-LAST:event_txt_PuestoActionPerformed

    private void txt_DepartamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_DepartamentoActionPerformed
        txt_Salario.requestFocusInWindow();
    }//GEN-LAST:event_txt_DepartamentoActionPerformed

    private void txt_SalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_SalarioActionPerformed
     
    }//GEN-LAST:event_txt_SalarioActionPerformed




  
    private void elegirRecorrido() {
        if (!hayArbol("Mostrar recorridos")) {
            return;
        }
        String[] opciones = {"Inorden", "Preorden", "Postorden", "Los tres"};
        int r = JOptionPane.showOptionDialog(this, "¿Qué recorrido desea mostrar?", "Mostrar recorridos",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        switch (r) {
            case 0 -> mostrarInOrden();
            case 1 -> mostrarPreOrden();
            case 2 -> mostrarPostOrden();
            case 3 -> mostrar("Recorridos (inorden, preorden y postorden)",
                    cuerpoInOrden() + "\n\n" + cuerpoPreOrden() + "\n\n" + cuerpoPostOrden());
            default -> { /* ventana cerrada: no hacer nada */ }
        }
    }

    private void mostrarInOrden() {
        mostrar("Recorrido inorden", cuerpoInOrden());
    }

    private void mostrarPreOrden() {
        mostrar("Recorrido preorden", cuerpoPreOrden());
    }

    private void mostrarPostOrden() {
        mostrar("Recorrido postorden", cuerpoPostOrden());
    }

    private String cuerpoInOrden() {
        return listaEmpleados("INORDEN (izquierdo, raíz, derecho) - ID ascendente", arbol.mostrarInOrden());
    }

    private String cuerpoPreOrden() {
        return listaEmpleados("PREORDEN (raíz, izquierdo, derecho)", arbol.mostrarPreOrden());
    }

    private String cuerpoPostOrden() {
        return listaEmpleados("POSTORDEN (izquierdo, derecho, raíz)", arbol.mostrarPostOrden());
    }

    /** Pregunta qué cálculo mostrar (amplitud, profundidad o ambos). */
    private void elegirCalculo() {
        if (!hayArbol("Calcular amplitud y profundidad")) {
            return;
        }
        String[] opciones = {"Amplitud", "Profundidad", "Ambas"};
        int r = JOptionPane.showOptionDialog(this, "¿Qué desea calcular?", "Amplitud y profundidad",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[2]);
        switch (r) {
            case 0 -> calcularAmplitud();
            case 1 -> calcularProfundidad();
            case 2 -> mostrar("Amplitud y profundidad", cuerpoAmplitud() + "\n\n" + cuerpoProfundidad());
            default -> { /* ventana cerrada: no hacer nada */ }
        }
    }

    private void calcularAmplitud() {
        mostrar("Calcular amplitud", cuerpoAmplitud());
    }

    private void calcularProfundidad() {
        mostrar("Calcular profundidad", cuerpoProfundidad());
    }

    private String cuerpoAmplitud() {
        int a = arbol.amplitud();
        return "Amplitud máxima: " + a + " nodo(s) en un mismo nivel."
                + "\n(Es el nivel más ancho, no el total de empleados; el total es " + arbol.getTamanio() + ".)";
    }

    private String cuerpoProfundidad() {
        int p = arbol.profundidad();
        return "Profundidad máxima: " + p + " nivel(es)."
                + "\n(Se mide en niveles: árbol vacío = 0, un solo nodo = 1.)";
    }

   

 

  
    private boolean hayArbol(String operacion) {
        if (arbol == null) {
            error(operacion, "Primero debe crear el árbol con el botón \"Crear Arbol\".");
            return false;
        }
        return true;
    }

   
    private void mostrar(String operacion, String texto) {
        txa_Resultados.setText("=== " + operacion.toUpperCase() + " ===\n" + texto);
        txa_Resultados.setCaretPosition(0);
    }

    
    private void error(String operacion, String mensaje) {
        mostrar(operacion, "ERROR: " + mensaje);
        JOptionPane.showMessageDialog(this, mensaje, operacion, JOptionPane.WARNING_MESSAGE);
    }

    private void limpiarCampos() {
        txt_ID.setText("");
        txt_Nombre.setText("");
        txt_Puesto.setText("");
        txt_Departamento.setText("");
        txt_Salario.setText("");
        txt_ID.requestFocusInWindow();
    }

    private static String dinero(Double d) {
        return String.format(Locale.US, "$%,.2f", d);
    }

    private static String detalle(Empleado e) {
        return "ID:           " + e.getId()
                + "\nNombre:       " + e.getNombre()
                + "\nPuesto:       " + e.getPuesto()
                + "\nDepartamento: " + e.getDepartamento()
                + "\nSalario:      " + dinero(e.getSalario());
    }

    private static String listaEmpleados(String titulo, List<Empleado> lista) {
        StringBuilder sb = new StringBuilder(titulo).append('\n');
        if (lista.isEmpty()) {
            return sb.append("(El árbol está vacío; no hay empleados que mostrar.)").toString();
        }
        int n = 1;
        for (Empleado e : lista) {
            sb.append(String.format("%2d) ID %d | %s | %s | %s | %s%n", n++, e.getId(), e.getNombre(),
                    e.getPuesto(), e.getDepartamento(), dinero(e.getSalario())));
        }
        return sb.toString().stripTrailing();
    }

    
    private static void estructura(NodoBST n, String prefijo, String rama, StringBuilder sb) {
        if (n == null) {
            return;
        }
        sb.append(prefijo).append(rama).append(n.getDato().getId())
                .append(" (").append(n.getDato().getNombre()).append(")\n");
        String hijoPrefijo = prefijo + (rama.isEmpty() ? "" : (rama.startsWith("├") ? "│   " : "    "));
        boolean hayDer = n.getDerecho() != null;
        estructura(n.getIzquierdo(), hijoPrefijo, hayDer ? "├─I: " : "└─I: ", sb);
        estructura(n.getDerecho(), hijoPrefijo, "└─D: ", sb);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new GUI_ArbolBinarioBusqueda().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PanelBotones;
    private javax.swing.JPanel PanelCamposEntrada;
    private javax.swing.JPanel PanelResultados;
    private javax.swing.JPanel PanelTitulo;
    private javax.swing.JPanel PanelVisualizarArbol;
    private javax.swing.JButton btn_Agregar;
    private javax.swing.JButton btn_Balancear;
    private javax.swing.JButton btn_Calcular;
    private javax.swing.JButton btn_Crear;
    private javax.swing.JButton btn_Destruir;
    private javax.swing.JButton btn_Eliminar;
    private javax.swing.JButton btn_Mostrar;
    private javax.swing.JButton btn_buscar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbl_Departamento;
    private javax.swing.JLabel lbl_ID;
    private javax.swing.JLabel lbl_Nombre;
    private javax.swing.JLabel lbl_Puesto;
    private javax.swing.JLabel lbl_Salario;
    private javax.swing.JTextArea txa_Resultados;
    private javax.swing.JTextField txt_Departamento;
    private javax.swing.JTextField txt_ID;
    private javax.swing.JTextField txt_Nombre;
    private javax.swing.JTextField txt_Puesto;
    private javax.swing.JTextField txt_Salario;
    // End of variables declaration//GEN-END:variables
}
